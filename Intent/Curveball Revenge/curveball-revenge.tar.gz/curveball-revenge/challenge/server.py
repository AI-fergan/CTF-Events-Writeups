import os

from random import randint
from hashlib import sha384
from types import NoneType
from typing import NamedTuple

class FinitePoint(NamedTuple):
    x: int
    y: int
    
PointAtInfinity = NoneType
PointType = FinitePoint | PointAtInfinity

def bits_msb_to_lsb(i: int):
    return [(i>>n)&1 for n in range(i.bit_length()-1,-1,-1)]

class Curve(NamedTuple):
    p: int
    a: int
    b: int
    G: FinitePoint
    n: int
    h: int

    def valid_element(self, fe: int):
        return 0 <= fe < self.p
    
    def valid_scalar(self, s: int):
        return 0 <= s < self.n

    def dbl(self, P: PointType) -> PointType:
        if P is None:
            return None
        lam = ((3*P.x*P.x+self.a) * pow(2*P.y, -1, self.p)) % self.p
        rx = (lam*lam - 2*P.x) % self.p
        ry = (lam*(P.x-rx) - P.y) % self.p
        return FinitePoint(rx, ry)
    
    def add(self, P: PointType, Q: PointType):
        match P, Q:
            case None, _:
                return Q
            case _, None:
                return P
            case _:
                if P.x == Q.x:
                    if P.y == Q.y:
                        return self.dbl(P)
                    return None
                lam = ((P.y-Q.y) * pow(P.x-Q.x, -1, self.p)) % self.p
                rx = (lam*lam - P.x - Q.x) % self.p
                ry = (lam*(P.x-rx) - P.y) % self.p
                return FinitePoint(rx, ry)
    
    def mult(self, P: PointType, scalar: int):
        if P is None:
            return None
        R = None
        G = P
        s = scalar % self.n
        while s:
            if s & 1:
                R = self.add(R, G)
            G = self.dbl(G)
            s >>= 1
        return R
    
    def shamir_addmul(self, u: int, v: int, P: PointType, Q: PointType):
        u_bits, v_bits = bits_msb_to_lsb(u), bits_msb_to_lsb(v)
        pre_cal = (
            (None, P),
            (Q, self.add(P, Q))
        )
        if len(u_bits) != len(v_bits):
            zero_bits = abs(len(u_bits)-len(v_bits))*[0]
            if len(u_bits) < len(v_bits):
                u_bits = zero_bits + u_bits
            else:
                v_bits = zero_bits + v_bits
        assert len(u_bits) == len(v_bits)
        R = None
        for u_bit, v_bit in zip(u_bits, v_bits):
            R = self.dbl(R)
            T = pre_cal[v_bit][u_bit]
            R = self.add(R, T)
        return R
    
    def fe_len(self):
        return (self.p.bit_length()+7)>>3
    
    def hash_message(self, m: bytes):
        nbits = self.n.bit_length()
        digest = sha384(m).digest()[:self.fe_len()]
        e = int.from_bytes(digest, "big")
        return (e >> max(0, 8*len(digest)-nbits) )
    
    def verify(self, PK: FinitePoint, R: int, S: int, msg: bytes):
        if (R <=0 or S <= 0 or self.n <= R or self.n <= S):
            return False
        Z = self.hash_message(msg)
        Sinv = pow(S, -1, self.n)
        match self.shamir_addmul((Z*Sinv)%self.n, (R*Sinv)%self.n, self.G, PK):
            case None:
                return False
            case P:
                return P.x == R
    
    def random_scalar(self) -> int:
        return randint(1, self.n - 1)
    
    def random_point(self) -> FinitePoint:
        # Assumption: all curve `p` primes are 3 (mod 4)
        assert self.p & 0x3 == 0x3
        while True:
            x = randint(1, self.p - 1)
            y_2 = (pow(x, 3, self.p) + self.a * x + self.b) % self.p
            # Check y_2 is quadratic residue
            if pow(y_2, (self.p-1)>>1, self.p) != 1:
                continue
            # Because of above assumption we can use a fast formula for y
            y = pow(y_2, (self.p+1) >> 2, self.p)
            # Make sure we are free of the co-factor
            match self.mult(FinitePoint(x, y), self.h):
                case None:
                    continue
                case R:
                    return R
    
    def hash_point(self, P: FinitePoint) -> bytes:
        p_octets = self.fe_len()
        x, y = P
        return sha384(x.to_bytes(p_octets, 'big') + y.to_bytes(p_octets, 'big')).digest()



secp112r1 = Curve(
    p=0xdb7c2abf62e35e668076bead208b,
    a=0xdb7c2abf62e35e668076bead2088,
    b=0x659ef8ba043916eede8911702b22,
    G=FinitePoint(
        0x09487239995a5ee76b55f9c2f098,
        0xa89ce5af8724c0a23e0e0ff77500),
    n=0xdb7c2abf62e35e7628dfac6561c5,
    h=0x01
)

secp112r2 = Curve(
    p=0xdb7c2abf62e35e668076bead208b,
    a=0x6127c24c05f38a0aaaf65c0ef02c,
    b=0x51def1815db5ed74fcc34c85d709,
    G=FinitePoint(
        0x4ba30ab5e892b4e1649dd0928643,
        0xadcd46f5882e3747def36e956e97),
    n=0x36df0aafd8b8d7597ca10520d04b,
    h=0x04
)


FLAG = os.getenv("FLAG")


def curve_choice():
    print("Curves:")
    print("  1. secp112r1")
    print("  2. secp112r2")
    curve_choice = int(input("Curve choice > "))
    match curve_choice:
        case 1:
            return secp112r1
        case 2:
            return secp112r2
        case _:
            raise ValueError(curve_choice)


def coord_choice(curve: Curve, param):
    val = int(input(f'{param}> '), 16)
    assert 0 <= val < curve.p
    return val


def scalar_choice(curve: Curve, param):
    val = int(input(f'{param}> '), 16)
    assert 0 <= val < curve.n
    return val


def main():
    try:
        H = b''
        target = b"See mama I got my revenge!"
        print("Curveball revenge! Welcome :-)")
        while True:
            action = int(
                input("Choose action:\n  1. Provision public-key.\n  2. Make a wish.\n > "))
            match action:
                case 1:
                    curve = curve_choice()
                    print("Provisioning public-key from the choosen curve.")
                    PK = curve.random_point()
                    H = curve.hash_point(PK)
                    print(f"\tx: {PK.x:028X}")
                    print(f"\ty: {PK.y:028X}")
                    print("Ready.")
                case 2:
                    if H == b'':
                        print("Not provisioned!")
                        continue
                    msg = input("What is your wish? ").encode()
                    print("Provide PK to verify your wish.")
                    curve = curve_choice()
                    x = coord_choice(curve, 'x')
                    y = coord_choice(curve, 'y')
                    PK = FinitePoint(x,y)
                    assert H == curve.hash_point(PK), "wrong pk hash"
                    print("Provide signature to verify your wish.")
                    R = scalar_choice(curve, 'R')
                    S = scalar_choice(curve, 'S')
                    if curve.verify(PK, R, S, msg):
                        print("Wish verified!")
                        if msg.startswith(target) and len(msg) < len(target) + 2:
                            print(f"Here you go: {FLAG}")
                        else:
                            print("Why are you here?")
                    else:
                        print("Wish denied!")
                case _:
                    print("Wot?")
    except Exception as e:
        print("Error", e)


if __name__ == "__main__":
    main()
