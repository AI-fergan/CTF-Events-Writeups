import os

from Crypto.Hash import SHA384
from Crypto.PublicKey import RSA
from Crypto.Signature import PKCS1_v1_5
from Crypto.Util.number import bytes_to_long, long_to_bytes


def oracle(key: RSA.RsaKey, ct: int):
        em = long_to_bytes(key._decrypt(ct), key.size_in_bytes()) # type: ignore
        return em[0] != 0

FLAG = os.getenv("FLAG")

def get_rsa_blob(prompt):
    return bytes.fromhex(input(prompt))

def main():
    try:
        assert FLAG is not None
        with open(os.getenv("SECRET_PATH", '/run/secrets/challenge_key')) as f:
            key = RSA.import_key(f.read())
        verifier = PKCS1_v1_5.new(key.public_key())
        target_hash = SHA384.new(b"FlagSheep")
        print("Welcome to mangerO challenge.")
        print(f"Here is my public key:\n\tn: {key.n}\n\te: {key.e}")
        remaining_actions = 2000
        while remaining_actions > 0:
            try:
                action = int(
                    input(f"Choose action ({2001-remaining_actions}/2000):\n  1. Provide signed-sheep.\n  2. Query the oracle.\n > "))
                remaining_actions -= 1
            except ValueError as e:
                print(f"Bad choice! {e}")
                continue
            match action:
                case 1:
                    try:
                        sig = get_rsa_blob("sig> ")
                        if verifier.verify(target_hash, sig):
                            print(f"The flag is: {FLAG}")
                        else:
                            print("Where is my signed sheep?")
                    except Exception as e:
                        print(f"Verify failed: {e}")
                case 2:
                    try:
                        ct = get_rsa_blob("ct> ")
                        if len(ct) != key.size_in_bytes():
                            print(f"Bad ciphertext len {len(ct)}!={key.size_in_bytes()}")
                            continue
                        C = bytes_to_long(ct)
                        if C > key.n:
                            print("Bad ciphertext larger than modulus!")
                            continue
                        if oracle(key, C):
                            print("True")
                        else:
                            print("False")
                    except Exception as e:
                        print(f"Oracle failed: {e}")
                case _:
                    print("Wot?")
        print("Too many actions where made :-( BYE!")
    except Exception as e:
        print("Error", e)


if __name__ == "__main__":
    main()
