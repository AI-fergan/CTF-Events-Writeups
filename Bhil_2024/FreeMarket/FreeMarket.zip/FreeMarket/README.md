# Free Market

The best NFT marketplace out there!
Can you beat the merchant and become a legend? 
You have 9 prompts, go.

